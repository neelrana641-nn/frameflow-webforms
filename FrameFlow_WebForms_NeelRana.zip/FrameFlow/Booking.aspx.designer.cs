namespace FrameFlow { public partial class BookingPage {
protected global::System.Web.UI.WebControls.Label Feedback;
protected global::System.Web.UI.WebControls.Panel Fields;
protected global::System.Web.UI.WebControls.DropDownList PackageSelect;
protected global::System.Web.UI.WebControls.TextBox NameInput, EmailInput, PhoneInput, DateInput, NotesInput;
protected global::System.Web.UI.WebControls.Button SubmitButton;
} }
