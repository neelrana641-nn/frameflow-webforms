namespace FrameFlow { public partial class MyBookingsPage {
protected global::System.Web.UI.WebControls.Label Feedback;
protected global::System.Web.UI.WebControls.TextBox ReferenceInput, EmailInput;
protected global::System.Web.UI.WebControls.Button FindButton, CancelButton;
protected global::System.Web.UI.WebControls.Panel Result;
protected global::System.Web.UI.WebControls.Literal PackageText, NameText, DateText, StatusText;
} }
