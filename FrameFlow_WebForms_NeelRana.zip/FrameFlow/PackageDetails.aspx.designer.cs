namespace FrameFlow { public partial class PackageDetailsPage {
protected global::System.Web.UI.WebControls.Literal NameText, DescriptionText, PriceText, DurationText, DeliverablesText;
protected global::System.Web.UI.WebControls.HyperLink BookLink;
} }
