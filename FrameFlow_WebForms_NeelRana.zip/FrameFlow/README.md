# FrameFlow — Photography Booking

A six-page ASP.NET Web Forms mini project for Neel Rana, BCA (Hons) Division I. The site presents photography packages and saves booking requests and contact inquiries in local JSON files.

## Pages and functions

1. `Default.aspx` — home and featured packages
2. `Packages.aspx` — package catalog from the shared C# model
3. `PackageDetails.aspx` — details and booking link for a selected package
4. `Booking.aspx` — validated booking form; generates a unique reference
5. `MyBookings.aspx` — look up a booking by reference and email; cancel a request
6. `Contact.aspx` — validated inquiry form, saved locally

The layout is responsive and shared through `Site.Master`. Records are saved in `App_Data/bookings.json` and `App_Data/inquiries.json` when forms are submitted; these private runtime files are excluded from Git. This is a classroom demo: there is no login, real availability calendar, payment processing, or automatic email. A booking is a request and does not confirm a photographer.

## Requirements and running

- Windows with **Visual Studio 2022** (or 2019) and the **ASP.NET and web development** workload
- **.NET Framework 4.8 Developer Pack** and IIS Express (normally installed with the workload)

1. Extract the ZIP and open `FrameFlow.sln` in Visual Studio.
2. Set `FrameFlow` as the startup project and `Default.aspx` as the start page if prompted.
3. Press **F5** or **Ctrl+F5**. Visual Studio starts IIS Express and opens the site.
4. Visit Packages → Details → Book a session. Copy the reference displayed after submission.
5. Open My booking, enter the reference and the same email, and check or cancel the request. Test Contact too.

If saving fails, grant the IIS Express process write access to the project's `App_Data` folder. The site uses only .NET Framework assemblies and does not require SQL Server or NuGet packages.

## GitHub submission

Suggested repository name: `frameflow-webforms` (check availability). After signing in to GitHub:

1. On GitHub, create a **new empty public repository** named `frameflow-webforms`. Leave README, `.gitignore`, and license unchecked because these files already exist here.
2. In Visual Studio, open **Git > Create Git Repository** for the extracted `FrameFlow` folder, select your GitHub account and choose the existing repository, then push. Or run these commands from the folder containing `FrameFlow.sln`:

   ```bash
   git init
   git add .
   git commit -m "Add FrameFlow ASP.NET Web Forms mini project"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/frameflow-webforms.git
   git push -u origin main
   ```

3. Refresh the repository page and verify `FrameFlow.sln`, `FrameFlow.csproj`, all six `.aspx` pages, C# files, and `README.md` are visible. Submit that repository URL.

Do not commit passwords, API keys, or personal booking data. GitHub account sign-up requires your chosen password and email verification; complete those steps on GitHub yourself.
