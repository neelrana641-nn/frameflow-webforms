using System;
using System.Web;
using System.Web.UI;
namespace FrameFlow { public partial class MyBookingsPage : Page {
protected void FindButton_Click(object sender, EventArgs e) { ShowBooking(); }
private void ShowBooking() { Feedback.Visible = false; Result.Visible = false; var item = Store.FindReservation(ReferenceInput.Text, EmailInput.Text); if (item == null) { Feedback.Visible = true; Feedback.CssClass = "feedback error"; Feedback.Text = "No booking matched that reference and email."; return; } Result.Visible = true; var package = Store.GetPackage(item.PackageId); PackageText.Text = HttpUtility.HtmlEncode(package == null ? item.PackageId : package.Name); NameText.Text = HttpUtility.HtmlEncode(item.Name); DateText.Text = item.Date.ToString("dd MMMM yyyy"); StatusText.Text = item.Cancelled ? "Cancelled" : "Request received"; CancelButton.Visible = !item.Cancelled; }
protected void CancelButton_Click(object sender, EventArgs e) { if (Store.CancelReservation(ReferenceInput.Text.Trim(), EmailInput.Text.Trim())) { ShowBooking(); Feedback.Visible = true; Feedback.CssClass = "feedback success"; Feedback.Text = "Your booking request was cancelled."; } else ShowBooking(); }
} }
