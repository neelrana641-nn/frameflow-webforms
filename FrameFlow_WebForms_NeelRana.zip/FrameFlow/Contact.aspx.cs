using System;
using System.Text.RegularExpressions;
using System.Web.UI;
namespace FrameFlow { public partial class ContactPage : Page {
protected void SendButton_Click(object sender, EventArgs e) { Feedback.Visible = true; Feedback.CssClass = "feedback error"; string email = EmailInput.Text.Trim(); if (string.IsNullOrWhiteSpace(NameInput.Text) || string.IsNullOrWhiteSpace(MessageInput.Text) || NameInput.Text.Trim().Length > 80 || MessageInput.Text.Length > 1000 || !Regex.IsMatch(email, @"^[^\s@]+@[^\s@]+\.[^\s@]+$")) { Feedback.Text = "Please enter your name, a valid email and a message."; return; } try { Store.SaveInquiry(new Inquiry { Name=NameInput.Text.Trim(), Email=email, Message=MessageInput.Text.Trim(), CreatedUtc=DateTime.UtcNow }); Feedback.CssClass = "feedback success"; Feedback.Text = "Message saved. Thank you!"; NameInput.Text = EmailInput.Text = MessageInput.Text = ""; } catch (Exception) { Feedback.Text = "Could not save your message. Check that App_Data is writable and try again."; } }
} }
