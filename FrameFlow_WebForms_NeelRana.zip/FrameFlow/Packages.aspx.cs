using System;
using System.Web.UI;
namespace FrameFlow { public partial class PackagesPage : Page { protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) { PackageList.DataSource = Store.Packages; PackageList.DataBind(); } } } }
