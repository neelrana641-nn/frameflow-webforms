namespace FrameFlow { public partial class PackagesPage { protected global::System.Web.UI.WebControls.Repeater PackageList; } }
