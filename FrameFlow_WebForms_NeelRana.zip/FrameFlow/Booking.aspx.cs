using System;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace FrameFlow { public partial class BookingPage : Page {
protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) { foreach (var item in Store.Packages) PackageSelect.Items.Add(new ListItem(item.Name + " · ₹" + item.Price.ToString("N0"), item.Id)); var choice = Store.GetPackage(Request.QueryString["id"]); if (choice != null) PackageSelect.SelectedValue = choice.Id; } }
protected void SubmitButton_Click(object sender, EventArgs e) {
    Feedback.Visible = true; Feedback.CssClass = "feedback error";
    DateTime date;
    string email = EmailInput.Text.Trim(); string phone = PhoneInput.Text.Trim();
    if (Store.GetPackage(PackageSelect.SelectedValue) == null || string.IsNullOrWhiteSpace(NameInput.Text) || NameInput.Text.Trim().Length > 80 || !Regex.IsMatch(email, @"^[^\s@]+@[^\s@]+\.[^\s@]+$") || !Regex.IsMatch(phone, @"^[+0-9][0-9\s-]{6,19}$") || !DateTime.TryParseExact(DateInput.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date) || date.Date < DateTime.Today || date.Date > DateTime.Today.AddYears(2) || NotesInput.Text.Length > 500) { Feedback.Text = "Please enter a valid name, email, phone and future date (within two years)."; return; }
    try { var booking = Store.CreateReservation(new Reservation { PackageId=PackageSelect.SelectedValue, Name=NameInput.Text.Trim(), Email=email, Phone=phone, Date=date, Notes=NotesInput.Text.Trim() }); Fields.Visible = false; Feedback.CssClass = "feedback success"; Feedback.Text = "Booking saved! Your reference is " + HttpUtility.HtmlEncode(booking.Reference) + ". Keep this reference and your email to view or cancel your booking. This is a request, not a confirmed appointment."; }
    catch (Exception) { Feedback.Text = "Could not save the booking. Check that App_Data is writable and try again."; }
}
} }
