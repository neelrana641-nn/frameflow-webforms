using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace FrameFlow
{
    public class PhotoPackage
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Tag { get; set; }
        public string Description { get; set; }
        public int Price { get; set; }
        public string Duration { get; set; }
        public string Deliverables { get; set; }
    }

    public class Reservation
    {
        public string Reference { get; set; }
        public string PackageId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public DateTime Date { get; set; }
        public string Notes { get; set; }
        public bool Cancelled { get; set; }
    }

    public class Inquiry
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Message { get; set; }
        public DateTime CreatedUtc { get; set; }
    }

    public static class Store
    {
        private static readonly object Gate = new object();
        private static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
        private static readonly PhotoPackage[] Catalog = {
            new PhotoPackage { Id="portraits", Name="Portrait Stories", Tag="For your best frame", Description="A relaxed portrait session with creative direction and natural edits.", Price=2499, Duration="60 minutes", Deliverables="15 edited digital photographs" },
            new PhotoPackage { Id="events", Name="Event Moments", Tag="Keep the celebration alive", Description="Coverage for birthdays, cultural events, and intimate celebrations.", Price=5999, Duration="3 hours", Deliverables="60 edited digital photographs" },
            new PhotoPackage { Id="reels", Name="Reel Studio", Tag="Made to move", Description="A focused shoot for a short social video with cinematic editing.", Price=3499, Duration="90 minutes", Deliverables="1 edited vertical reel + 5 stills" }
        };

        public static IEnumerable<PhotoPackage> Packages { get { return Catalog; } }
        public static PhotoPackage GetPackage(string id) { return Catalog.FirstOrDefault(p => string.Equals(p.Id, id, StringComparison.OrdinalIgnoreCase)); }

        private static string PathFor(string file) { return HttpContext.Current.Server.MapPath("~/App_Data/" + file); }
        private static List<T> Read<T>(string file)
        {
            string path = PathFor(file);
            if (!File.Exists(path)) return new List<T>();
            string contents = File.ReadAllText(path);
            return string.IsNullOrWhiteSpace(contents) ? new List<T>() : Json.Deserialize<List<T>>(contents);
        }
        private static void Write<T>(string file, List<T> rows)
        {
            string path = PathFor(file);
            Directory.CreateDirectory(System.IO.Path.GetDirectoryName(path));
            // Write to a temporary file before replacing the saved data.
            string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            File.WriteAllText(temp, Json.Serialize(rows));
            if (File.Exists(path)) File.Replace(temp, path, null);
            else File.Move(temp, path);
        }
        public static Reservation CreateReservation(Reservation item)
        {
            lock (Gate)
            {
                var rows = Read<Reservation>("bookings.json");
                item.Reference = "FF-" + Guid.NewGuid().ToString("N").Substring(0, 10).ToUpperInvariant();
                rows.Add(item);
                Write("bookings.json", rows);
                return item;
            }
        }
        public static Reservation FindReservation(string reference, string email)
        {
            lock (Gate)
            {
                return Read<Reservation>("bookings.json").FirstOrDefault(r =>
                    string.Equals(r.Reference, (reference ?? "").Trim(), StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(r.Email, (email ?? "").Trim(), StringComparison.OrdinalIgnoreCase));
            }
        }
        public static bool CancelReservation(string reference, string email)
        {
            lock (Gate)
            {
                var rows = Read<Reservation>("bookings.json");
                var item = rows.FirstOrDefault(r => string.Equals(r.Reference, reference, StringComparison.OrdinalIgnoreCase) && string.Equals(r.Email, email, StringComparison.OrdinalIgnoreCase));
                if (item == null || item.Cancelled) return false;
                item.Cancelled = true;
                Write("bookings.json", rows);
                return true;
            }
        }
        public static void SaveInquiry(Inquiry item)
        {
            lock (Gate)
            {
                var rows = Read<Inquiry>("inquiries.json");
                rows.Add(item);
                Write("inquiries.json", rows);
            }
        }
    }
}
