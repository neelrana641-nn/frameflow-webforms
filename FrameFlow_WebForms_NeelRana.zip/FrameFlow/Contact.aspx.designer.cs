namespace FrameFlow { public partial class ContactPage {
protected global::System.Web.UI.WebControls.Label Feedback;
protected global::System.Web.UI.WebControls.TextBox NameInput, EmailInput, MessageInput;
protected global::System.Web.UI.WebControls.Button SendButton;
} }
