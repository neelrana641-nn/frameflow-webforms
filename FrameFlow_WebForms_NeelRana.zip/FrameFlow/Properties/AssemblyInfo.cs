using System.Reflection;
[assembly: AssemblyTitle("FrameFlow")]
[assembly: AssemblyDescription("Photography session booking mini project")]
[assembly: AssemblyCompany("Neel Rana")]
[assembly: AssemblyProduct("FrameFlow")]
[assembly: AssemblyVersion("1.0.0.0")]
