using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace FrameFlow { public partial class PackageDetailsPage : Page {
protected void Page_Load(object sender, EventArgs e) { var item = Store.GetPackage(Request.QueryString["id"]); if (item == null) { Response.Redirect("~/Packages.aspx", true); return; } NameText.Text = HttpUtility.HtmlEncode(item.Name); DescriptionText.Text = HttpUtility.HtmlEncode(item.Description); PriceText.Text = "₹" + item.Price.ToString("N0"); DurationText.Text = HttpUtility.HtmlEncode(item.Duration); DeliverablesText.Text = HttpUtility.HtmlEncode(item.Deliverables); BookLink.NavigateUrl = "~/Booking.aspx?id=" + HttpUtility.UrlEncode(item.Id); }
} }
